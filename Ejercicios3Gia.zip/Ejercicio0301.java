
package ejercicios;
import java.util.Scanner;
public class Ejercicio0301 {
     public static void main(String[] args)  {
         
         Scanner teclado = new Scanner(System.in);
         
        int bucle;
        for (bucle = 0; bucle <=10; bucle++){
            //haz algo x veces exactas
            //while se reptite hasta que pasa algo. entre (x e y) veces
            System.out.println("Esto es un bucle ");
        }
      
     }
 

     }