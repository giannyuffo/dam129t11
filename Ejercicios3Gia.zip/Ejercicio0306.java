
package ejercicios;
import java.util.Scanner;
public class Ejercicio0306 {
     public static void main(String[] args)  {
         
        Scanner teclado = new Scanner(System.in);
         
        int n=100;
        
        { for (n=100; n>=0; n--)
              if (n%2==0)  
                System.out.println(n);
        } 
     }}